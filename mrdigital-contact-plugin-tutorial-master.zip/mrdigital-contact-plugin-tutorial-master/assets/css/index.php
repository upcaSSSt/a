<?php

die('You should not be here');